from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from model import ChatRequest, ChatResponse
from agent import agent

app = FastAPI(title="Smart Budget Travel Planner API")

# Add CORS Middleware to allow requests from frontend (e.g. React/Vite dev server)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust as needed for security in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Smart Budget Travel Planner API is running"}

@app.post("/api/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    try:
        # Invoke the LangGraph/LangChain agent
        response = agent.invoke({"messages": [{"role": "user", "content": request.message}]})
        
        # Safely extract the assistant response content
        if "messages" in response and len(response["messages"]) > 0:
            assistant_reply = response["messages"][-1].content
        else:
            raise HTTPException(status_code=500, detail="Invalid response structure from agent")
            
        return ChatResponse(response=assistant_reply)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
