from langchain_mistralai.chat_models import ChatMistralAI
from langchain.agents import create_agent
from langchain_core.messages import SystemMessage

import config

llm = ChatMistralAI(model="mistral-large-latest", api_key=config.MISTRAL_API_KEY)

agent = create_agent(llm)

if __name__ == "__main__":
    response = agent.invoke({"messages": [{"role": "user", "content": "hello"}]})
    print(response["messages"][-1].content)